var udp  =  wx.createUDPSocket();
var port = udp.bind(6655);//绑定本机端口号，端口号可以自己设置
var num = 0;
var light_flag =false;
var receive_flag = false;
var sendMsg_flag = false;

Page({
  data:{
    hostport:'6655',
    sendMsgbuff:'',
    message:'ReceiveMsg here',
    clickId:-1,
    unloadMsg:'UnoladPage',
    receivedData: '',
    showFrontBlindSpot: false, // 根据实际情况设置默认值
    showRearBlindSpot: false, // 根据实际情况设置默认值
    showLeftBlindSpot: false, // 根据实际情况设置默认值
    showRightBlindSpot: false, // 根据实际情况设置默认值
    soundFile: 'alarm.mp3',
  },

    // 接收到数据时调用的方法
    updateImage: function(receivedData) {
      let newImage = '';
      switch (receivedData) {
        case '1':
      this.setData({ showFrontBlindSpot: true }); // 使用 this.setData
      break;
    case '2':
      this.setData({ showRearBlindSpot: true }); // 使用 this.setData
      break;
    case '3':
      this.setData({ showLeftBlindSpot: true }); // 使用 this.setData
      break;
    case '4':
      this.setData({ showRightBlindSpot: true }); // 使用 this.setData
      break;
    default:
      this.setData({
        showFrontBlindSpot: false,
        showRearBlindSpot: false,
        showLeftBlindSpot: false,
        showRightBlindSpot: false
      });
      }
      this.setData({ currentImage: newImage });
      if(receivedData-'1'>=0&&receivedData-'1'<=3)
      {
        const innerAudioContext = wx.createInnerAudioContext();
        innerAudioContext.src = 'pages/index/alarm.mp3'; // 设置本地音频文件路径
        innerAudioContext.play(); // 播放
       // innerAudioContext.destroy(); // 释放音频资源
        console.log('success'); 
    };
    },

  /*休眠函数*/
  sleep: function(milSec) {
    return new Promise(resolve => {
    setTimeout(resolve, milSec)
    })
  },

  onLoad() {
    var that = this;

    udp.onMessage(function (res) {
      console.log(res);
      var unit8Arr = new Uint8Array(res.message);
      var encodedString = String.fromCharCode.apply(null, unit8Arr),
      decodedString = decodeURIComponent(escape(encodedString)); //防止中文乱码
      that.setData({
        receivedData: decodedString,
      })
      console.log(decodedString); 
      that.updateImage(decodedString);
    });
    /*监听数据包消息*/
    udp.onListening(function (res) {
      console.log(res);
    });
  },
  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  onUnload:function() {
    this.unloadPage();
    // udp.close();//退出页面时将socket关闭
  },

})




