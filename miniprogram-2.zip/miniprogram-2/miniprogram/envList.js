const envList = [{"envId":"cloud1-4gy0si6pc6d596e4","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}