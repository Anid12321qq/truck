
# Developed by Muxi_Gorgy
# Kalman filter visualization : After -Red  Origin  -Blue
# Python version
import numpy as np
from pykalman import KalmanFilter
import os
import cv2
import matplotlib.pyplot as plt

ordi_record=[]
x = []
y = []
real_record_x = []
real_record_y = []
test = []
over_flag = 0
INTERFASE = 0.1
SURPASS_GATE = 680000
CHANGE_TARGET = 5

def Kalman_traj_smooth(trajaction, process_noise_std, measurement_noise_std):
    '''
    使用卡尔曼滤波器对轨迹数据进行平滑处理
    
    参数
    ----
    data : DataFrame
        轨迹数据，包含time、lon、lat三列
    process_noise_std : float or list
        过程噪声标准差，如果是list，则认为是过程噪声协方差矩阵的对角线元素
    measurement_noise_std : float or list
        观测噪声标准差，如果是list，则认为是观测噪声协方差矩阵的对角线元素

    返回
    ----
    data : DataFrame
        平滑后的轨迹数据
    '''
    data_rec_x = []
    data_rec_y = []
    timestamps = range(len(trajaction))
    # F-状态转移矩阵
    transition_matrix = np.array([[1, 0, 1, 0],
                                  [0, 1, 0, 1],
                                  [0, 0, 1, 0],
                                  [0, 0, 0, 1]])
    # H-观测矩阵
    observation_matrix = np.array([[1, 0, 0, 0],
                                   [0, 1, 0, 0]])
    # R-观测噪声协方差矩阵
    # 如果measurement_noise_std是list，则认为是观测噪声协方差矩阵的对角线元素
    if isinstance(measurement_noise_std, list):
        observation_covariance = np.diag(measurement_noise_std)**2
    else:
        observation_covariance = np.eye(2) * measurement_noise_std**2
    # Q-过程噪声协方差矩阵
    # 如果process_noise_std是list，则认为是过程噪声协方差矩阵的对角线元素
    if isinstance(process_noise_std, list):
        transition_covariance = np.diag(process_noise_std)**2
    else:
        transition_covariance = np.eye(4) * process_noise_std**2
    # 初始状态
    initial_state_mean = [trajaction[0][0], trajaction[0][1], 0, 0]
    # 初始状态协方差矩阵
    initial_state_covariance = np.eye(4) * 1
    # 初始化卡尔曼滤波器
    kf = KalmanFilter(
        transition_matrices=transition_matrix,
        observation_matrices=observation_matrix,
        initial_state_mean=initial_state_mean,
        initial_state_covariance=initial_state_covariance,
        observation_covariance=observation_covariance,
        transition_covariance=transition_covariance
    )
    # 使用卡尔曼滤波器进行平滑处理
    # 先创建变量存储平滑后的状态
    smoothed_states = np.zeros((len(trajaction), 4))
    # 将初始状态存储到平滑后的状态中
    smoothed_states[0,:] = initial_state_mean
    # 从第二个状态开始，进行循环迭代
    current_state = initial_state_mean
    current_covariance = initial_state_covariance
    for i in range(1, len(trajaction)):
        # 计算时间间隔
        dt = 1
        # 更新状态转移矩阵
        kf.transition_matrices = np.array([[1, 0, dt, 0],
                                           [0, 1, 0, dt],
                                           [0, 0, 1, 0],
                                           [0, 0, 0, 1]])
        # 根据当前状态的预测情况与观测结果进行状态估计
        current_state, current_covariance = kf.filter_update(
            current_state, current_covariance, trajaction[i]
        )
        # 将平滑后的状态存储到变量中
        smoothed_states[i, :] = current_state 
    # 将平滑后的数据结果添加到原始数据中
        data_rec_x= smoothed_states[:, 0]
        data_rec_y = smoothed_states[:, 1]
    return [data_rec_x,data_rec_y]


def convert_yolo_to_coordinates(x_center, y_center, width, height, image_width=1920, image_height=1080):
    x_min = int((x_center - (width / 2)) * image_width)
    y_min = int((y_center - (height / 2)) * image_height)
    x_max = int((x_center + (width / 2)) * image_width)
    y_max = int((y_center + (height / 2)) * image_height)
    return (x_min, y_min, x_max, y_max)

def s_calc(a):
    a1, a2, a3, a4 = convert_yolo_to_coordinates(float(a[1]), float(a[2]), float(a[3]), float(a[4]))
    return (a4 - a2) * (a3 - a1)

def over_detect(index):
    global over_flag,ordi_record,SURPASS_GATE
    eq = 0
    now_ori = ordi_record[index]
    x_dif = now_ori[1]-now_ori[0]
    y_dif = now_ori[3]-now_ori[2]
    s = x_dif*y_dif
    if(s > SURPASS_GATE):
        over_flag = 1
    if(over_flag):
        c_d_x = ordi_record[index][0]
        p_d_x = ordi_record[index-1][0]
        pp_d_x = ordi_record[index-2][0]
        ppp_d_x = ordi_record[index-3][0]
        eq = c_d_x + p_d_x - pp_d_x - ppp_d_x
        eq = eq/2
        over_flag = 0
    if(eq>10):
        text = 'OVER'
        print(index,"超车_flag",now_ori)

# 获取文件夹路径
folder_path = "/Users/mxmr.t/Downloads/predict4/labels"
# 获取文件夹中的所有txt文件
txt_files = [file for file in os.listdir(folder_path) if file.endswith(".txt")]

# 按照文件名称的序号顺序排序文件列表
txt_files.sort(key=lambda x: int(''.join(filter(str.isdigit, x))))

# 初始化基准数据
baseline_data = None

# 存储正确的数据
correct_data = []
i = 1
flag = 0
# 逐个读取txt文件
for file in txt_files:
    file_path = os.path.join(folder_path, file)
    with open(file_path, 'r') as f:
        if flag :
        # 检查当前文件中的数据是否满足条件
            if len(lines) >= 1:
                all_data_larger_than_threshold = True
                print(i,baseline_data)
                for line in lines:
                    data = line.strip().split()
                    #print(i,float(data[1]),float(baseline_data[1]))
                    if abs(float(data[1]) - float(baseline_data[1])) <= INTERFASE:
                        #print(i,"enter")
                        print(i,'enter flag')
                        all_data_larger_than_threshold = False
                        correct_data.append(data)
                        baseline_data = data
                        break
                    elif (s_calc(data)/s_calc(baseline_data))> CHANGE_TARGET :
                        correct_data.append(data)
                        baseline_data = data
                        break

                if all_data_larger_than_threshold:
                    correct_data.append(baseline_data)
            else:
                correct_data.append(baseline_data)

        lines = f.readlines()
        if(flag!=1):
            if len(lines) >= 1:
                baseline_data = lines[0].strip().split()
                correct_data.append(baseline_data)
                flag = 1
                print(i,baseline_data)
            else :
                baseline_data = [4,0,0,0,0] #没有坐标出现
                correct_data.append(baseline_data)
        
        i = i + 1
# 打印正确的数据
i=1
for data in correct_data:
    i=i+1
    x_min = float(data[1])
    x_max = float(data[3])
    y_min = float(data[2])
    y_max = float(data[4])
    test.append([float(x_min),float(y_min)])
    x_min, y_min, x_max, y_max = convert_yolo_to_coordinates(float(data[1]),float(data[2]),float(data[3]),float(data[4]))
    #记录标准值
    real_record_x.append(int((x_min+x_max)/2))
    real_record_y.append(int((y_min+y_max)/2))
    ordi_record.append([int((x_min+x_max)/2),int((y_min+y_max)/2)])

#一组测试数据
test_recorddata = [[417, 259], [453, 248], [466, 247], [507, 276], [502, 260], [549, 235], [586, 237], [597, 230], [612, 218], [690, 195], [703, 188], [823, 183], [933, 147], [1752, 226], [974, 153], [999, 147], [1023, 141], [1075, 150], [1099, 134], [1129, 134], [1159, 142], [1258, 150], [1267, 159], [1267, 154], [1276, 115], [1266, 117], [1218, 116], [1137, 112], [1084, 117], [1069, 120], [1077, 123], [1213, 159], [1218, 160], [1210, 153], [1205, 159], [1165, 142], [300, 186], [1113, 136], [988, 116], [915, 190], [889, 196], [879, 170], [870, 162], [846, 165], [848, 182], [847, 193], [837, 193], [817, 192], [807, 197], [814, 201]]
x_test = [417, 453, 466, 507, 502, 549, 586, 597, 612, 690, 703, 823, 933, 1752, 974, 999, 1023, 1075, 1099, 1129, 1159, 1258, 1267, 1267, 1276, 1266, 1218, 1137, 1084, 1069, 1077, 1213, 1218, 1210, 1205, 1165, 300, 1113, 988, 915, 889, 879, 870, 846, 848, 847, 837, 817, 807, 814]
y_test = [259, 248, 247, 276, 260, 235, 237, 230, 218, 195, 188, 183, 147, 226, 153, 147, 141, 150, 134, 134, 142, 150, 159, 154, 115, 117, 116, 112, 117, 120, 123, 159, 160, 153, 159, 142, 186, 136, 116, 190, 196, 170, 162, 165, 182, 193, 193, 192, 197, 201]
traj_smoothed = Kalman_traj_smooth(test_recorddata, 
                                   process_noise_std = 0.01, 
                                   measurement_noise_std = 2)

x_processed = (traj_smoothed[0])
y_processed = (traj_smoothed[1])
fig, ax = plt.subplots()
bx = ax.twinx()

# 绘制x和y的数据点
ax.plot(x_test,y_test,marker='o', label='Before')
bx.plot(x_processed,y_processed,marker='o', color='red', label='After')

# ax.set_xlim(0, 1920)
# ax.set_ylim(0, 1080)
# bx.set_xlim(0, 1920)
# bx.set_ylim(0, 1080)

# 添加标题和标签
ax.set_title('Carman filter')
ax.set_xlabel('X')
ax.set_ylabel('Y')


# 显示图例
ax.legend(loc='upper left')
bx.legend(loc='upper right')

# 显示图形
plt.show()