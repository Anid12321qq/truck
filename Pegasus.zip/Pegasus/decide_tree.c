#include "stdio.h"
#define INTERFACE_VALUE 150
#define STILL 0
#define LEFT 1
#define RIGHT 2
#define NONE_OVER
#define SCALEGATE 50000
#define CLOSEWINDOWGATE_RIGHT 1800
#define CLOSEWINDOWGATE_LEFT 200
#define LEFT_IN 1
#define LEFT_45_in 2
#define RIGHT_45_in 3
#define RIGHT_in 4
#define LEFT_OUT 5
#define MIDDLE_OUT 6
#define RIGHT_OUT 7
#define APPROACH_OUT_GATE 20000
#define RIGHT_SHIFT 100
#define LEFT_SHIFT -100

int ordi_pre[4] = {0};
int base_data[4] = {600, 500, 1000, 900};
int ori_buffer[16] = {0};
int center_dir_record = 0;
int toward_dir = 0;
int baseline_settle_flag = 0;

void data_receive(int *orination)
{
    // FIFO
    for (int i = 12; i >= 4; i -= 4)
    {
        for (int j = 1; j <= 4; j++)
        {
            ori_buffer[i + 4 - j] = ori_buffer[i - j];
        }
    }
    for (int i = 0; i < 4; i++)
    {
        ori_buffer[i] = orination[i];
    }
}

void base_data_settle(int *orination)
{
    int x_min = orination[0];
    int y_min = orination[1];
    int x_max = orination[2];
    int y_max = orination[3];
    int scale = s_cal(orination);
    if (scale > 20000)
    {
        if ((x_min + x_max) >= 0 && (x_min + x_max) <= 1920 * 2)
        {
            if ((y_min + y_max) >= 0 && (y_min + y_max) <= 1080 * 2)
            {
                baseline_settle_flag = 1;
            }
        }
    }
}

int s_cal(int *orination) // 计算最新一帧图像面积
{
    return (orination[2] - orination[0]) * (orination[3] - orination[1]);
}

// 趋势方向和中心所在区域判断,返回一个趋势方向
int dirction_judge(int *orination)
{
    // 通过比较四个数据的x坐标差值给出一个方向判定；
    int dir_sum = 0;
    int x1, x2, x3, x4, x_dif_sum, x_ave;
    x1 = orination[0];
    x2 = orination[4];
    x3 = orination[8];
    x4 = orination[12];
    x_dif_sum = (x1 - x3 + x2 - x4) / 2;
    if (x_dif_sum < LEFT_SHIFT)
    {
        toward_dir = LEFT;
        return LEFT;
    }
    else if (x_dif_sum > RIGHT_SHIFT)
    {
        toward_dir = RIGHT;
        return RIGHT;
    }
    else
    {
        return STILL;
    }
    x_ave = (x1 + x2 + x3 + x4) / 4;

    if (x_ave < 1920 / 2)
    {
        center_dir_record = LEFT;
    }
    else
    {
        center_dir_record = RIGHT;
    }
}

void data_pre_process(int *orination)
{
    int dir = dirction_judge(orination);
    int offset = 0;
    if (dir == LEFT)
    {
        offset = -10;
    }
    if (dir == RIGHT)
    {
        offset = 10;
    }
    if (orination[0] - base_data[0] > INTERFACE_VALUE) // 如果大于扰动数据，则忽略该数据
    {                                                  // 同时对x轴坐标进行方向补偿
        orination[0] = base_data[0] + offset;
        orination[1] = base_data[1];
        orination[2] = base_data[2];
        orination[3] = base_data[3];
    }
    // 把数据交给buffer
    data_receive(orination);
    // 重设basedata
    for (int i = 0; i < 4; i++)
    {
        base_data[i] = orination[i];
    }
}

// 如果返回的是0则为没有接近的
int approach_detect()
{
    int scale = s_cal(ori_buffer);
    int x_min = ori_buffer[0];
    int x_max = ori_buffer[2];
    int x_mid = (x_max + x_min) / 2;
    int dir = 0;
    if (scale > APPROACH_OUT_GATE)
    {
        dir = MIDDLE_OUT;
        if (x_mid < (1920 / 2))
            dir = RIGHT_OUT;
        if (x_mid > (1920 / 2))
            dir = LEFT_OUT;
    }
    return 0;
}

int over_detect()
{
    int scale = s_cal(ori_buffer);
    int x_min = ori_buffer[0];
    int x_max = ori_buffer[2];
    int x_mid = (x_max + x_min) / 2;
    int flag1 = 0;
    int flag2 = 0;
    int flag3 = 0;
    if (scale > SCALEGATE)
    {
        flag1 = 1;
    }
    if (flag1)
    {
        if (toward_dir == center_dir_record)
        {
            flag2 = 1;
        }
    }
    if (flag2)
    {
        if (center_dir_record == RIGHT)
        {
            if (x_max > CLOSEWINDOWGATE_RIGHT)
                flag3 = 1;
        }
        if (center_dir_record == LEFT)
        {
            if (x_min < CLOSEWINDOWGATE_LEFT)
                flag3 = 1;
        }
    }

    if (flag3)
    {
        if (toward_dir == RIGHT)
            return LEFT; // 图像刚好相反
        if (toward_dir == LEFT)
            return RIGHT;
    }
    else
        return NONE_OVER;
}

int main()
{

    int frameData[][4] = {
        {282, 174, 552, 345},
        {318, 154, 588, 343},
        {318, 154, 615, 340},
        {354, 177, 660, 376},
        {357, 160, 648, 360},
        {402, 137, 696, 334},
        {429, 135, 744, 340},
        {447, 132, 747, 329},
        {459, 120, 765, 317},
        {531, 106, 849, 284},
        {549, 95, 858, 281},
        {663, 92, 984, 275},
        {789, 73, 1077, 222},
        {1650, 123, 1854, 329},
        {834, 70, 1113, 236},
        {858, 67, 1140, 227},
        {885, 67, 1161, 216},
        {927, 64, 1224, 236},
        {966, 53, 1233, 216},
        {987, 53, 1272, 216},
        {1011, 59, 1308, 225},
        {1107, 61, 1410, 239},
        {1128, 61, 1407, 258},
        {1128, 59, 1407, 250},
        {1140, 28, 1413, 202},
        {1122, 33, 1410, 202},
        {1062, 36, 1374, 196},
        {993, 30, 1281, 194},
        {936, 36, 1233, 199},
        {921, 30, 1218, 210},
        {933, 42, 1221, 205},
        {1059, 64, 1368, 255},
        {1059, 61, 1377, 258},
        {1053, 59, 1368, 247},
        {1047, 61, 1344, 258},
        {1017, 45, 1314, 239},
        {264, 120, 336, 253},
        {942, 53, 1284, 219},
        {837, 30, 1140, 202},
        {735, 70, 1095, 309},
        {717, 81, 1062, 312},
        {702, 42, 1056, 298},
        {678, 47, 1062, 278},
        {666, 53, 1026, 278},
        {678, 56, 1029, 309},
        {681, 70, 1017, 315},
        {669, 75, 1026, 312},
        {654, 73, 1029, 317},
        {642, 81, 1017, 315},
        {630, 84, 1002, 320},
        {624, 92, 1002, 345},
        {630, 92, 1020, 337},
        {624, 92, 1047, 345},
        {612, 87, 1053, 348},
        {633, 67, 1050, 343},
        {639, 47, 1056, 337},
        {624, 42, 1068, 337},
        {618, 33, 1071, 343},
        {648, 33, 1095, 340},
        {597, 33, 1098, 300}};

    int numFrames = sizeof(frameData) / sizeof(frameData[0]);

    // 创建新数组并将每行的4个数据交给新数组
    int newData[numFrames * 4];
    for (int i = 0; i < numFrames; i++)
    {
        newData[i * 4] = frameData[i][0];
        newData[i * 4 + 1] = frameData[i][1];
        newData[i * 4 + 2] = frameData[i][2];
        newData[i * 4 + 3] = frameData[i][3];
    }

    int orination[4] = {0};
    int index = 0;
    while (1)
    {
        for (int i = 0; i < 4; i++)
        {
            orination[index+i] = newData[index+i];
        }
        if (!baseline_settle_flag)
        {
            base_data_settle(orination);
        }
        if (baseline_settle_flag)
        {
            data_pre_process(orination);
            over_detect();
        }
        index = index + 4;
        if(index > numFrames){
            break;
        }
    }
}