#include <stdio.h>
#include <stdlib.h>

typedef struct {
    double x;
    double y;
} Point;

typedef struct {
    double x_min;
    double y_min;
    double x_max;
    double y_max;
} BoundingBox;

typedef struct {
    double x;
    double y;
    double width;
    double height;
} YoloBox;

typedef struct {
    Point *data;
    size_t length;
} PointArray;

typedef struct {
    BoundingBox *data;
    size_t length;
} BoundingBoxArray;

typedef struct {
    YoloBox *data;
    size_t length;
} YoloBoxArray;

typedef struct {
    double *data;
    size_t length;
} DoubleArray;

void kalman_traj_smooth(PointArray trajaction, double process_noise_std, double measurement_noise_std, PointArray *data_rec) {
    size_t i;
    PointArray data_rec_x;
    PointArray data_rec_y;
    double transition_matrix[4][4] = {
        {1, 0, 1, 0},
        {0, 1, 0, 1},
        {0, 0, 1, 0},
        {0, 0, 0, 1}
    };
    double observation_matrix[2][4] = {
        {1, 0, 0, 0},
        {0, 1, 0, 0}
    };
    double observation_covariance[2][2];
    double transition_covariance[4][4];
    double initial_state_mean[4] = {trajaction.data[0].x, trajaction.data[0].y, 0, 0};
    double initial_state_covariance[4][4] = {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}};
    double current_state[4];
    double current_covariance[4][4];
    double dt = 1;

    if (process_noise_std < 0 || measurement_noise_std < 0 || trajaction.length == 0) {
        data_rec->data = NULL;
        data_rec->length = 0;
        return;
    }

    if (trajaction.length > 0) {
        data_rec_x.data = malloc(trajaction.length * sizeof(Point));
        data_rec_x.length = trajaction.length;
        data_rec_y.data = malloc(trajaction.length * sizeof(Point));
        data_rec_y.length = trajaction.length;
    } else {
        data_rec_x.data = NULL;
        data_rec_x.length = 0;
        data_rec_y.data = NULL;
        data_rec_y.length = 0;
    }

    if (measurement_noise_std > 0) {
        observation_covariance[0][0] = measurement_noise_std * measurement_noise_std;
        observation_covariance[1][1] = measurement_noise_std * measurement_noise_std;
    }

    if (process_noise_std > 0) {
        transition_covariance[0][0] = process_noise_std * process_noise_std;
        transition_covariance[1][1] = process_noise_std * process_noise_std;
        transition_covariance[2][2] = process_noise_std * process_noise_std;
        transition_covariance[3][3] = process_noise_std * process_noise_std;
    }

    for (i = 0; i < trajaction.length; i++) {
        current_state[0] = trajaction.data[i].x;
        current_state[1] = trajaction.data[i].y;
        current_state[2] = 0;
        current_state[3] = 0;
        current_covariance[0][0] = initial_state_covariance[0][0];
        current_covariance[0][1] = initial_state_covariance[0][1];
        current_covariance[0][2] = initial_state_covariance[0][2];
        current_covariance[0][3] = initial_state_covariance[0][3];
        current_covariance[1][0] = initial_state_covariance[1][0];
        current_covariance[1][1] = initial_state_covariance[1][1];
        current_covariance[1][2] = initial_state_covariance[1][2];
        current_covariance[1][3] = initial_state_covariance[1][3];
        current_covariance[2][0] = initial_state_covariance[2][0];
        current_covariance[2][1] = initial_state_covariance[2][1];
        current_covariance[2][2] = initial_state_covariance[2][2];
        current_covariance[2][3] = initial_state_covariance[2][3];
        current_covariance[3][0] = initial_state_covariance[3][0];
        current_covariance[3][1] = initial_state_covariance[3][1];
        current_covariance[3][2] = initial_state_covariance[3][2];
        current_covariance[3][3] = initial_state_covariance[3][3];

        for (size_t j = 1; j < trajaction.length; j++) {
            transition_matrix[0][2] = dt;
            transition_matrix[1][3] = dt;

            current_state[0] = trajaction.data[j].x;
            current_state[1] = trajaction.data[j].y;

            current_state[0] += current_state[0] - trajaction.data[j - 1].x - trajaction.data[j - 2].x;
            current_state[0] /= 2;

            kf_filter_update(current_state, current_covariance, trajaction.data[j]);

            data_rec_x.data[j].x = current_state[0];
            data_rec_x.data[j].y = current_state[1];
            data_rec_y.data[j].x = current_state[0];
            data_rec_y.data[j].y = current_state[1];
        }
    }

    data_rec->data = data_rec_x.data;
    data_rec->length = data_rec_x.length;
}

void convert_yolo_to_coordinates(double x_center, double y_center, double width, double height, int image_width, int image_height, BoundingBox *bounding_box) {
    bounding_box->x_min = (x_center - (width / 2)) * image_width;
    bounding_box->y_min = (y_center - (height / 2)) * image_height;
    bounding_box->x_max = (x_center + (width / 2)) * image_width;
    bounding_box->y_max = (y_center + (height / 2)) * image_height;
}

double s_calc(BoundingBox bounding_box) {
    return (bounding_box.y_max - bounding_box.y_min) * (bounding_box.x_max - bounding_box.x_min);
}

void smooth_trajectory(PointArray test_recorddata, double process_noise_std, double measurement_noise_std, PointArray *traj_smoothed) {
    kalman_traj_smooth(test_recorddata, process_noise_std, measurement_noise_std, traj_smoothed);
}

int main() {
    // 常量定义
    const double INTERFASE = 0.1;
    const double SURPASS_GATE = 680000;
    const double CHANGE_TARGET = 5;

    // 数据定义
    BoundingBoxArray ordi_record;
    PointArray test_recorddata;
    PointArray real_record;
    PointArray traj_smoothed;
    int over_flag = 0;

    // 一组测试数据
    Point test_recorddata_entries[] = {
        {417, 259}, {453, 248}, {466, 247}, {507, 276}, {502, 260}, {549, 235}, {586, 237}, {597, 230}, {612, 218}, {690, 195},
        {703, 188}, {823, 183}, {933, 147}, {1752, 226}, {974, 153}, {999, 147}, {1023, 141}, {1075, 150}, {1099, 134}, {1129, 134},
        {1159, 142}, {1258, 150}, {1267, 159}, {1267, 154}, {1276, 115}, {1266, 117}, {1218, 116}, {1137, 112}, {1084, 117}, {1069, 120},
        {1077, 123}, {1213, 159}, {1218, 160}, {1210, 153}, {1205, 159}, {1165, 142}, {300, 186}, {1113, 136}, {988, 116}, {915, 190},
        {889, 196}, {879, 170}, {870, 162}, {846, 165}, {848, 182}, {847, 193}, {837, 193}, {817, 192}, {807, 197}, {814, 201}
    };
    size_t test_recorddata_length = sizeof(test_recorddata_entries) / sizeof(test_recorddata_entries[0]);
    test_recorddata.data = test_recorddata_entries;
    test_recorddata.length = test_recorddata_length;

    smooth_trajectory(test_recorddata, 0.01, 2, &traj_smoothed);

    DoubleArray x_processed;
    DoubleArray y_processed;
    x_processed.data = malloc(traj_smoothed.length * sizeof(double));
    x_processed.length = traj_smoothed.length;
    y_processed.data = malloc(traj_smoothed.length * sizeof(double));
    y_processed.length = traj_smoothed.length;

    for (size_t j = 0; j < traj_smoothed.length; j++) {
        x_processed.data[j] = traj_smoothed.data[j].x;
        y_processed.data[j] = traj_smoothed.data[j].y;
    }

    // 绘制图形部分未翻译，需要使用相应的图形库进行实现

    // 释放动态分配的内存
    free(test_recorddata.data);
    free(real_record.data);
    free(traj_smoothed.data);
    free(x_processed.data);
    free(y_processed.data);

    return 0;
}