/*
 * Copyright (c) 2022 HiSilicon (Shanghai) Technologies CO., LIMITED.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * Developed:   Tao_Muxi: Overtaking Algorithm
                Ouyang_Tianyi: Kalman_filter C_Version
                Li_Jiayu: Communication Section
 * 
 */

 /*/DEBUG REPORT/*/
#define OVERTAKING_REPORT   1
#define DATA_REPORT       1
#define DIRECTION_REPORT 1

#include <hi_types_base.h>
#include <hi_early_debug.h>
#include <hi_stdlib.h>
#include <hi_uart.h>
#include <hi_task.h>
#include <app_demo_uart.h>
#include <iot_uart.h>

#include "ohos_init.h"
#include "cmsis_os2.h"
#include "iot_gpio_ex.h"
#include "hi_io.h"
#include "iot_gpio.h"
#include "hisignalling_protocol.h"

#include "iot_errno.h"
#include "hi_gpio.h"

#include "stdio.h"
#include <unistd.h>
#include<stdlib.h> 
#include<math.h>

#include "lwip/netifapi.h"
#include <hi_watchdog.h>
#include "udp_config.h"
#include <string.h>
#include <errno.h>



#define INTERFACE_VALUE 800
#define STILL 0
#define LEFT 1
#define RIGHT 2
#define NONE_OVER 0
#define SCALEGATE 60000
#define CLOSEWINDOWGATE_RIGHT 1100
#define CLOSEWINDOWGATE_LEFT 200
#define LEFT_IN 1
#define LEFT_45_in 2
#define RIGHT_45_in 3
#define RIGHT_in 4
#define LEFT_OUT 5
#define MIDDLE_OUT 6
#define RIGHT_OUT 7
#define APPROACH_OUT_GATE 20000
#define RIGHT_SHIFT 10
#define LEFT_SHIFT -10
#define ZERO_TAR_GATE 15

#define IOT_PWM_BEEP_left 6
#define IOT_PWM_BEEP_right 7
#define IOT_PWM_BUZZER 10
#define IOT_PWM_PORT_PWM0 0
#define IOT_PWM_PORT_PWM1 1
#define IOT_PWM_PORT_PWM3 3
#define viberate_mode_value 85
#define LED_TEST_GPIO 9
#define LED_INTERVAL_TIME_US 300000

#define AHT20_BAUDRATE (400 * 1000)
#define AHT20_I2C_IDX 0


#define UDP_TASK_STACKSIZE  0x1000
#define UDP_TASK_PRIOR 27
#define UDP_TASK_NAME "UDP_demo"

#define INVAILD_SOCKET          (-1)
#define FREE_CPU_TIME_20MS      (20)
#define INVALID_VALUE           "202.202.202.202"

#define NATIVE_IP_ADDRESS       "192.168.50.93" // 用户查找本地IP后需要进行修改
#define WECHAT_MSG_LIGHT_ON     "_light_on"
#define WECHAT_MSG_LIGHT_OFF    "_light_off"
#define DEVICE_MSG_LIGHT_ON     "device_light_on"
#define DEVICE_MSG_LIGHT_OFF    "device_light_off"
#define WECHAT_MSG_UNLOAD_PAGE  "UnoladPage"
#define RECV_DATA_FLAG_OTHER    (2)
#define HOST_PORT               (5566)
#define DEVICE_PORT             (6655)

#define UDP_RECV_LEN (255)



int ori_buffer[16] = {0};
int Record_state = 0;
uint32_t ordi_pre[4] = {0};
uint32_t base_data[4] = {600, 500, 800, 800};
uint32_t center_dir_record = 0;
uint32_t toward_dir = 0;
uint32_t baseline_settle_flag = 0;
uint32_t debug_count = 1;
uint32_t non_trag_count = 1;



hi_u8 g_sendUartBuff[UART_BUFF_SIZE];
UartDefConfig recConfig = {0};

typedef void (*FnMsgCallBack)(hi_gpio_value val);

typedef struct FunctionCallback {
    hi_bool stop;
    hi_u32 conLost;
    hi_u32 queueID;
    hi_u32 iotTaskID;
    FnMsgCallBack msgCallBack;
}FunctionCallback;
FunctionCallback g_gfnCallback;

void DeviceConfigInit(hi_gpio_value val)
{
    hi_io_set_func(HI_IO_NAME_GPIO_9, HI_IO_FUNC_GPIO_9_GPIO);
    hi_gpio_set_dir(HI_GPIO_IDX_9, HI_GPIO_DIR_OUT);
    hi_gpio_set_ouput_val(HI_GPIO_IDX_9, val);
}

int  DeviceMsgCallback(FnMsgCallBack msgCallBack)
{
    g_gfnCallback.msgCallBack = msgCallBack;
    return 0;
}

void WeChatControlDeviceMsg(hi_gpio_value val)
{
    DeviceConfigInit(val);
}


int UdpTransportInit(struct sockaddr_in serAddr, struct sockaddr_in remoteAddr)
{
    int sServer = socket(AF_INET, SOCK_DGRAM, 0);
    if (sServer == INVAILD_SOCKET) {
        printf("create server socket failed\r\n");
        close(sServer);
    }
    // 本地主机ip和端口号
    serAddr.sin_family = AF_INET;
    serAddr.sin_port = htons(HOST_PORT);
    serAddr.sin_addr.s_addr = inet_addr(NATIVE_IP_ADDRESS);
	printf("sServer:%d\r\n", sServer);
    hi_sleep(100);
    if (bind(sServer, (struct sockaddr*)&serAddr, sizeof(serAddr)) == -1) {
        printf("bind socket failed\r\n");
        close(sServer);
    }
    // 对方ip和端口号
    remoteAddr.sin_family = AF_INET;
    remoteAddr.sin_port = htons(DEVICE_PORT);
    serAddr.sin_addr.s_addr = htons(INADDR_ANY);

    return sServer;
}

#define CLIENT_IP_ADDRESS       "192.168.50.143" // 客户端的IP地址
#define CLIENT_PORT             (6655)          // 客户端的端口号

/*
 * crc32 Verification implementation
 */
static const unsigned int crc32table[] = {
    0x00000000L, 0x77073096L, 0xee0e612cL, 0x990951baL,
    0x076dc419L, 0x706af48fL, 0xe963a535L, 0x9e6495a3L,
    0x0edb8832L, 0x79dcb8a4L, 0xe0d5e91eL, 0x97d2d988L,
    0x09b64c2bL, 0x7eb17cbdL, 0xe7b82d07L, 0x90bf1d91L,
    0x1db71064L, 0x6ab020f2L, 0xf3b97148L, 0x84be41deL,
    0x1adad47dL, 0x6ddde4ebL, 0xf4d4b551L, 0x83d385c7L,
    0x136c9856L, 0x646ba8c0L, 0xfd62f97aL, 0x8a65c9ecL,
    0x14015c4fL, 0x63066cd9L, 0xfa0f3d63L, 0x8d080df5L,
    0x3b6e20c8L, 0x4c69105eL, 0xd56041e4L, 0xa2677172L,
    0x3c03e4d1L, 0x4b04d447L, 0xd20d85fdL, 0xa50ab56bL,
    0x35b5a8faL, 0x42b2986cL, 0xdbbbc9d6L, 0xacbcf940L,
    0x32d86ce3L, 0x45df5c75L, 0xdcd60dcfL, 0xabd13d59L,
    0x26d930acL, 0x51de003aL, 0xc8d75180L, 0xbfd06116L,
    0x21b4f4b5L, 0x56b3c423L, 0xcfba9599L, 0xb8bda50fL,
    0x2802b89eL, 0x5f058808L, 0xc60cd9b2L, 0xb10be924L,
    0x2f6f7c87L, 0x58684c11L, 0xc1611dabL, 0xb6662d3dL,
    0x76dc4190L, 0x01db7106L, 0x98d220bcL, 0xefd5102aL,
    0x71b18589L, 0x06b6b51fL, 0x9fbfe4a5L, 0xe8b8d433L,
    0x7807c9a2L, 0x0f00f934L, 0x9609a88eL, 0xe10e9818L,
    0x7f6a0dbbL, 0x086d3d2dL, 0x91646c97L, 0xe6635c01L,
    0x6b6b51f4L, 0x1c6c6162L, 0x856530d8L, 0xf262004eL,
    0x6c0695edL, 0x1b01a57bL, 0x8208f4c1L, 0xf50fc457L,
    0x65b0d9c6L, 0x12b7e950L, 0x8bbeb8eaL, 0xfcb9887cL,
    0x62dd1ddfL, 0x15da2d49L, 0x8cd37cf3L, 0xfbd44c65L,
    0x4db26158L, 0x3ab551ceL, 0xa3bc0074L, 0xd4bb30e2L,
    0x4adfa541L, 0x3dd895d7L, 0xa4d1c46dL, 0xd3d6f4fbL,
    0x4369e96aL, 0x346ed9fcL, 0xad678846L, 0xda60b8d0L,
    0x44042d73L, 0x33031de5L, 0xaa0a4c5fL, 0xdd0d7cc9L,
    0x5005713cL, 0x270241aaL, 0xbe0b1010L, 0xc90c2086L,
    0x5768b525L, 0x206f85b3L, 0xb966d409L, 0xce61e49fL,
    0x5edef90eL, 0x29d9c998L, 0xb0d09822L, 0xc7d7a8b4L,
    0x59b33d17L, 0x2eb40d81L, 0xb7bd5c3bL, 0xc0ba6cadL,
    0xedb88320L, 0x9abfb3b6L, 0x03b6e20cL, 0x74b1d29aL,
    0xead54739L, 0x9dd277afL, 0x04db2615L, 0x73dc1683L,
    0xe3630b12L, 0x94643b84L, 0x0d6d6a3eL, 0x7a6a5aa8L,
    0xe40ecf0bL, 0x9309ff9dL, 0x0a00ae27L, 0x7d079eb1L,
    0xf00f9344L, 0x8708a3d2L, 0x1e01f268L, 0x6906c2feL,
    0xf762575dL, 0x806567cbL, 0x196c3671L, 0x6e6b06e7L,
    0xfed41b76L, 0x89d32be0L, 0x10da7a5aL, 0x67dd4accL,
    0xf9b9df6fL, 0x8ebeeff9L, 0x17b7be43L, 0x60b08ed5L,
    0xd6d6a3e8L, 0xa1d1937eL, 0x38d8c2c4L, 0x4fdff252L,
    0xd1bb67f1L, 0xa6bc5767L, 0x3fb506ddL, 0x48b2364bL,
    0xd80d2bdaL, 0xaf0a1b4cL, 0x36034af6L, 0x41047a60L,
    0xdf60efc3L, 0xa867df55L, 0x316e8eefL, 0x4669be79L,
    0xcb61b38cL, 0xbc66831aL, 0x256fd2a0L, 0x5268e236L,
    0xcc0c7795L, 0xbb0b4703L, 0x220216b9L, 0x5505262fL,
    0xc5ba3bbeL, 0xb2bd0b28L, 0x2bb45a92L, 0x5cb36a04L,
    0xc2d7ffa7L, 0xb5d0cf31L, 0x2cd99e8bL, 0x5bdeae1dL,
    0x9b64c2b0L, 0xec63f226L, 0x756aa39cL, 0x026d930aL,
    0x9c0906a9L, 0xeb0e363fL, 0x72076785L, 0x05005713L,
    0x95bf4a82L, 0xe2b87a14L, 0x7bb12baeL, 0x0cb61b38L,
    0x92d28e9bL, 0xe5d5be0dL, 0x7cdcefb7L, 0x0bdbdf21L,
    0x86d3d2d4L, 0xf1d4e242L, 0x68ddb3f8L, 0x1fda836eL,
    0x81be16cdL, 0xf6b9265bL, 0x6fb077e1L, 0x18b74777L,
    0x88085ae6L, 0xff0f6a70L, 0x66063bcaL, 0x11010b5cL,
    0x8f659effL, 0xf862ae69L, 0x616bffd3L, 0x166ccf45L,
    0xa00ae278L, 0xd70dd2eeL, 0x4e048354L, 0x3903b3c2L,
    0xa7672661L, 0xd06016f7L, 0x4969474dL, 0x3e6e77dbL,
    0xaed16a4aL, 0xd9d65adcL, 0x40df0b66L, 0x37d83bf0L,
    0xa9bcae53L, 0xdebb9ec5L, 0x47b2cf7fL, 0x30b5ffe9L,
    0xbdbdf21cL, 0xcabac28aL, 0x53b39330L, 0x24b4a3a6L,
    0xbad03605L, 0xcdd70693L, 0x54de5729L, 0x23d967bfL,
    0xb3667a2eL, 0xc4614ab8L, 0x5d681b02L, 0x2a6f2b94L,
    0xb40bbe37L, 0xc30c8ea1L, 0x5a05df1bL, 0x2d02ef8dL};



/*-------------------------宏定义噪声-------------------------*/

// 过程噪声
#define ProcessNoiseStd 0.01
// 观测噪声
#define MeasurementNoiseStd 2

/*-------------------------参数声明与数据和矩阵初始化方法-------------------------*/

// 结构体存储矩阵的行数和列数以及指向矩阵的二级指针
typedef struct 
{
    int Row;
    int Column;
    float** Array;
}Matrix;

// 结构体存储坐标
typedef struct 
{
    float X;
    float Y;
}Coordinate;

// 实现变长一维数组
float* CustomizeData(int size){
    float* Data = (float*)malloc(sizeof(float) * size);
    return Data;
}

// 释放一维数组内存
void FreeData(float* Data){
    free(Data);
}

// Data: 用于向矩阵赋值，此处未做元素个数与数组长度匹配检查
// rows，columns: 指定矩阵的行数和列数
Matrix* MatrixConfigure(float* Data, int rows, int columns){
    Matrix* TempMatrix = (Matrix*)malloc(sizeof(Matrix));
    TempMatrix -> Row = rows;
    TempMatrix -> Column = columns;
    float** pl = (float**)malloc(sizeof(float*)*rows);
    //遍历每行矩阵，确定每行一维矩阵的维度
    for(int i=0;i<rows;i++) 
    {
        //确定列数空间内存
        pl[i]=(float*)malloc(sizeof(float)*columns); 
    }
    for(int i = 0; i < rows; i++){
        for(int k = 0; k < columns; k++){
            pl[i][k] = Data[i*columns+k];
        }
    } 
    TempMatrix -> Array = pl;
    return TempMatrix;
}

// 释放指定矩阵的内存
void FreeMatrix(Matrix* Matrix){
    // 释放开辟的数组内存
    int rows = Matrix->Row;
    float** pl = Matrix->Array;
    for (int j = 0; j < rows; j++)
        free(pl[j]);
    free(pl);
    // 释放矩阵内存
    free(Matrix);
}

// Kalman_smooth函数调用结束时统一释放动态分配的内存
void Kalman_free(Matrix* PredictedStateMean, Matrix* PredictedStateCov, Matrix* mid_temp_mat, Matrix* mid_temp_mat2, Matrix* TransposedMat, Matrix* PredictedObservationMean, Matrix* PredictedObsercationCov, Matrix* Observation, Matrix* InversedMat, Matrix* KalmanGain) {
    FreeMatrix(PredictedStateMean);
    FreeMatrix(PredictedStateCov);
    FreeMatrix(mid_temp_mat);
    FreeMatrix(mid_temp_mat2);
    FreeMatrix(TransposedMat);
    FreeMatrix(PredictedObservationMean);
    FreeMatrix(PredictedObsercationCov);
    FreeMatrix(Observation);
    FreeMatrix(InversedMat);
    FreeMatrix(KalmanGain);
}


/*-------------------------参数初始化-------------------------*/

// 状态转移矩阵 F
Matrix* F;
// 观测矩阵 H
Matrix* H;
// 观测噪声协方差矩阵 R
Matrix* R;
// 过程噪声协方差矩阵 Q
Matrix* Q;
// 初始状态矩阵
Matrix* InitialStateMean;
// 当前状态矩阵
Matrix* CurrentStateMean;
// 初始状态协方差矩阵
Matrix* InitialStateCov;
// 当前状态协方差矩阵
Matrix* CurrentStateCov;
// 存储矩阵元素
float* DataBuffer;
// 矩阵元素个数
int BufferSize;

// 关键矩阵初始化
void KeyMatrixInitialization(){
    // 初始化状态转移矩阵 F
    /*F矩阵初始化为：
    [
        1 0 1 0
        0 1 0 1
        0 0 1 0
        0 0 0 1
    ]*/
    BufferSize = 16;
    DataBuffer = CustomizeData(BufferSize);
    DataBuffer[0] = 1;
    DataBuffer[1] = 0;
    DataBuffer[2] = 1;
    DataBuffer[3] = 0;
    DataBuffer[4] = 0;
    DataBuffer[5] = 1;
    DataBuffer[6] = 0;
    DataBuffer[7] = 1;
    DataBuffer[8] = 0;
    DataBuffer[9] = 0;
    DataBuffer[10] = 1;
    DataBuffer[11] = 0;
    DataBuffer[12] = 0;
    DataBuffer[13] = 0;
    DataBuffer[14] = 0;
    DataBuffer[15] = 1;
    F = MatrixConfigure(DataBuffer, 4, 4);
    FreeData(DataBuffer);
    // 初始化观测矩阵 H
    /*H矩阵初始化为
    [
        1 0 0 0
        0 1 0 0
    ]
    */
    BufferSize = 8;
    DataBuffer = CustomizeData(BufferSize);
    DataBuffer[0] = 1;
    DataBuffer[1] = 0;
    DataBuffer[2] = 0;
    DataBuffer[3] = 0;
    DataBuffer[4] = 0;
    DataBuffer[5] = 1;
    DataBuffer[6] = 0;
    DataBuffer[7] = 0;
    H = MatrixConfigure(DataBuffer, 2, 4);
    FreeData(DataBuffer);
    // 初始化观测噪声协方差矩阵 R
    /*
    R矩阵初始化
    [
        MeasurementNoiseStd^2 0
        0 MeasurementNoiseStd^2
    ]
    */ 
   BufferSize = 4;
   DataBuffer = CustomizeData(BufferSize);
   DataBuffer[0] = MeasurementNoiseStd * MeasurementNoiseStd;
   DataBuffer[1] = 0;
   DataBuffer[2] = 0;
   DataBuffer[3] = MeasurementNoiseStd * MeasurementNoiseStd;  
   R = MatrixConfigure(DataBuffer, 2, 2);
   FreeData(DataBuffer);
   // 初始化过程噪声协方差矩阵 Q
    /*
    Q矩阵初始化
    [
        ProcessNoiseStd^2 0 0 0
        0 ProcessNoiseStd^2 0 0
        0 0 ProcessNoiseStd^2 0
        0 0 0 ProcessNoiseStd^2
    ]
    */
   BufferSize = 16;
   DataBuffer = CustomizeData(BufferSize);
   DataBuffer[0] = ProcessNoiseStd * ProcessNoiseStd;
   DataBuffer[1] = 0;
   DataBuffer[2] = 0;
   DataBuffer[3] = 0;
   DataBuffer[4] = 0;
   DataBuffer[5] = ProcessNoiseStd * ProcessNoiseStd;
   DataBuffer[6] = 0;
   DataBuffer[7] = 0;
   DataBuffer[8] = 0;
   DataBuffer[9] = 0;
   DataBuffer[10] = ProcessNoiseStd * ProcessNoiseStd;
   DataBuffer[11] = 0;
   DataBuffer[12] = 0;
   DataBuffer[13] = 0;
   DataBuffer[14] = 0;
   DataBuffer[15] = ProcessNoiseStd * ProcessNoiseStd;
   Q = MatrixConfigure(DataBuffer, 4, 4);
   FreeData(DataBuffer);
   // 初始化状态矩阵: [0 0 0 0]
   BufferSize = 4;
   DataBuffer = CustomizeData(BufferSize);
   DataBuffer[0] = 0;
   DataBuffer[1] = 0;
   DataBuffer[2] = 0;
   DataBuffer[3] = 0;
   InitialStateMean = MatrixConfigure(DataBuffer, 1, 4);
   CurrentStateMean = MatrixConfigure(DataBuffer, 1, 4);
   FreeData(DataBuffer);
   // 初始化协方差矩阵
   /*
   [
    1 0 0 0
    0 1 0 0
    0 0 1 0
    0 0 0 1
   ]
   */
  BufferSize = 16;
  DataBuffer = CustomizeData(BufferSize);
  DataBuffer[0] = 1;
  DataBuffer[1] = 0;
  DataBuffer[2] = 0;
  DataBuffer[3] = 0;
  DataBuffer[4] = 0;
  DataBuffer[5] = 1;
  DataBuffer[6] = 0;
  DataBuffer[7] = 0;
  DataBuffer[8] = 0;
  DataBuffer[9] = 0;
  DataBuffer[10] = 1;
  DataBuffer[11] = 0;
  DataBuffer[12] = 0;
  DataBuffer[13] = 0;
  DataBuffer[14] = 0;
  DataBuffer[15] = 1;
  InitialStateCov = MatrixConfigure(DataBuffer, 4, 4);
  CurrentStateCov = MatrixConfigure(DataBuffer, 4, 4);
  FreeData(DataBuffer);
}

// 矩阵初始化
Matrix* MatrixInitialization(int row, int column){
    Matrix* customized_matrix = (Matrix*)malloc(sizeof(Matrix));
    // 总元素个数
    int temp_buffer_size = row * column;
    // 为Buffer开辟内存
    DataBuffer = CustomizeData(temp_buffer_size);
    // 初始化所有元素
    for(int i = 0; i < temp_buffer_size; i++){
        DataBuffer[i] = 0;
    }
    customized_matrix = MatrixConfigure(DataBuffer, row, column);
    FreeData(DataBuffer);
    return customized_matrix;
}

// 矩阵元素复制，未做维度匹配检查
void DuplicateMatrix(Matrix* SrcMat, Matrix* DstMat){
    for(int i = 0; i < SrcMat -> Row; i++){
        for(int j = 0; j < SrcMat -> Column; j++){
            DstMat -> Array[i][j] = SrcMat -> Array[i][j];
        }
    }
}
/*-------------------------矩阵运算方法定义-------------------------*/
// 矩阵转置，此处未做维度匹配检查
void Transpose(Matrix* SrcMat, Matrix* DstMat)
{
    int SrcRow = SrcMat -> Row;
    int SrcColumn = SrcMat -> Column;
    for(int i = 0; i < SrcRow; i++){
        for(int k = 0; k < SrcColumn; k++){
            DstMat -> Array[k][i] = SrcMat -> Array[i][k];
        }
    }
}

// 矩阵求逆，未做维度匹配检查
// SrcMat来源矩阵，DstMat目的矩阵
void Inverse(Matrix* SrcMat, Matrix* DstMat)
{
    // 获取矩阵维度，默认两个矩阵维度匹配且为方阵
    int dimension = SrcMat -> Column;
	int i, j, k;
    // 最大值与中间值存储
	float max, temp;
    //临时矩阵
    float** temp_mat = (float**)malloc(sizeof(float*)*dimension);
    //遍历每行矩阵，确定每行一维矩阵的维度
    for(i = 0; i < dimension; i++) 
    {
        //确定列数空间内存
        temp_mat[i]=(float*)malloc(sizeof(float) * dimension); 
    }
	//将A矩阵存放在临时矩阵t[n][n]中
	for (i = 0; i < dimension; i++)
	{
		for (j = 0; j < dimension; j++)
		{
			temp_mat[i][j] = SrcMat -> Array[i][j];
		}
	}
	//初始化B矩阵为单位阵
	for (i = 0; i < dimension; i++)
	{
		for (j = 0; j < dimension; j++)
		{
			DstMat -> Array[i][j] = (i == j) ? (float)1 : 0;
		}
	}
	for (i = 0; i < dimension; i++)
	{
		//寻找主元
		max = temp_mat[i][i];
		k = i;
		for (j = i + 1; j < dimension; j++)
		{
			if (fabs(temp_mat[j][i]) > fabs(max))
			{
				max = temp_mat[j][i];
				k = j;
			}
		}
		//如果主元所在行不是第i行，进行行交换
		if (k != i)
		{
			for (j = 0; j < dimension; j++)
			{
				temp = temp_mat[i][j];
				temp_mat[i][j] = temp_mat[k][j];
				temp_mat[k][j] = temp;
				//B伴随交换
				temp = DstMat -> Array[i][j];
				DstMat -> Array[i][j] = DstMat -> Array[k][j];
				DstMat -> Array[k][j] = temp;
			}
		}
		//判断主元是否为0, 若是, 则矩阵A不是满秩矩阵,不存在逆矩阵
		if (temp_mat[i][i] == 0)
		{
			printf("矩阵不存在逆");
			system("pause");
			exit(0);
		}
		//消去A的第i列除去i行以外的各行元素
		temp = temp_mat[i][i];
		for (j = 0; j < dimension; j++)
		{
            //主对角线上的元素变为1
			temp_mat[i][j] = temp_mat[i][j] / temp;    
            //伴随计算
			DstMat -> Array[i][j] = DstMat -> Array[i][j] / temp;        
		}
        //第0行->第n行
		for (j = 0; j < dimension; j++)        
		{
            //不是第i行
			if (j != i)                
			{
				temp = temp_mat[j][i];
                //第j行元素 - i行元素*j列i行元素
				for (k = 0; k < dimension; k++)        
				{
					temp_mat[j][k] = temp_mat[j][k] - temp_mat[i][k] * temp;
					DstMat -> Array[j][k] = DstMat -> Array[j][k] - DstMat -> Array[i][k] * temp;
				}
			}
		}
	}
    // 释放内存
    for (int j = 0; j < dimension; j++)
        free(temp_mat[j]);
    free(temp_mat);
}

// 矩阵乘法，未做维度匹配检查，顺序为：MatA X MatB
void Multiply(Matrix* MatA, Matrix* MatB, Matrix* DstMat)
{
    // 获得矩阵A的行数和列数
    int row_a = MatA -> Row;
    int column_a = MatA -> Column;
    int column_b = MatB -> Column;
    // 将结果行数和列数保存在目的矩阵中
    // int column_b = MatB -> Column;
    // DstMat -> Row = row_a;
    // DstMat -> Column = column_b;
    for(int i = 0; i < row_a; i++){
        // 取矩阵A中的每一行，取矩阵B中的每一列
        for(int j = 0; j < column_b; j++){
            float sum = 0;
            // 取矩阵A指定行中的每一个元素，取矩阵B指定列中的每一个元素
            for(int k = 0; k < column_a; k++){
                sum += (MatA -> Array[i][k]) * (MatB -> Array[k][j]);
            }
            DstMat -> Array[i][j] = sum;
        }

    }
}

// 矩阵加法，未做维度匹配检查
void Addition(Matrix* MatA, Matrix* MatB, Matrix* DstMat){
    for(int i = 0; i < MatA -> Row; i++){
        for(int j = 0; j < MatA -> Column; j++){
            DstMat -> Array[i][j] = MatA -> Array[i][j] + MatB -> Array[i][j];
        }
    }
}

// 矩阵减法， 未做维度匹配检查，顺序为：MatA - MatB
void Subtraction(Matrix* MatA, Matrix* MatB, Matrix* DstMat){
        for(int i = 0; i < MatA -> Row; i++){
        for(int j = 0; j < MatA -> Column; j++){
            DstMat -> Array[i][j] = MatA -> Array[i][j] - MatB -> Array[i][j];
        }
    }
}

/*-------------------------卡尔曼滤波-------------------------*/
// SrcCoord: 输入坐标，为结构体
Coordinate Kalman_smooth(Coordinate SrcCoord){
    Coordinate CorrectedCoord;
    // 若从未调用过该函数并传入坐标，则将第一个传入的坐标存储并返回传入坐标
    if(InitialStateMean -> Array[0][0] == 0 && InitialStateMean -> Array[0][1] == 0){
        InitialStateMean -> Array[0][0] = SrcCoord.X;
        InitialStateMean -> Array[0][1] = SrcCoord.Y;
        DuplicateMatrix(InitialStateMean, CurrentStateMean);
        DuplicateMatrix(InitialStateCov, CurrentStateCov);
        CorrectedCoord.X = SrcCoord.X;
        CorrectedCoord.Y = SrcCoord.Y;
        return CorrectedCoord;
    }
    else{
        /*-------------------------轨迹预测-------------------------*/
            // 定义预测坐标矩阵
        Matrix* PredictedStateMean = MatrixInitialization(1, 4);
            // 定义预测协方差矩阵
        Matrix* PredictedStateCov = MatrixInitialization(4, 4);
            // 定义中间转置矩阵
        Matrix* TransposedMat = MatrixInitialization(4, 1);
            // ----计算预测坐标矩阵----
        Transpose(CurrentStateMean, TransposedMat);
        Multiply(F, TransposedMat, TransposedMat);
        Transpose(TransposedMat, PredictedStateMean);
        // ----计算预测协方差矩阵---
            // 定义中间矩阵
        Matrix* mid_temp_mat = MatrixInitialization(4, 4);
        Multiply(F, CurrentStateCov, mid_temp_mat);
            // 定义当前协方差矩阵转置矩阵
        FreeMatrix(TransposedMat);
        TransposedMat = MatrixInitialization(4, 4);
        Transpose(F, TransposedMat);
        Multiply(mid_temp_mat, TransposedMat, PredictedStateCov);
        Addition(PredictedStateCov, Q, PredictedStateCov);
        /*-------------------------预测矫正-------------------------*/
        Matrix* PredictedObservationMean = MatrixInitialization(1, 2);
        Matrix* PredictedObsercationCov = MatrixInitialization(2, 2);
        FreeMatrix(TransposedMat);
        TransposedMat = MatrixInitialization(4, 1);
            // 获得状态预测矩阵转置
        Transpose(PredictedStateMean, TransposedMat);
        FreeMatrix(mid_temp_mat);
        mid_temp_mat = MatrixInitialization(2, 1);
        Multiply(H, TransposedMat, mid_temp_mat);
        Transpose(mid_temp_mat, PredictedObservationMean);
        FreeMatrix(mid_temp_mat);
        mid_temp_mat = MatrixInitialization(2, 4);
        FreeMatrix(TransposedMat);
        TransposedMat = MatrixInitialization(4, 2);
        Transpose(H, TransposedMat);
        Multiply(H, PredictedStateCov, mid_temp_mat);
        Multiply(mid_temp_mat, TransposedMat, PredictedObsercationCov);
        Addition(PredictedObsercationCov, R, PredictedObsercationCov);

        // ----计算卡尔曼增益----
        Matrix* KalmanGain = MatrixInitialization(4, 2);
        FreeMatrix(mid_temp_mat);
        mid_temp_mat = MatrixInitialization(4, 2);
        Multiply(PredictedStateCov, TransposedMat, mid_temp_mat);
            // 获得观测协方差矩阵
        Matrix* InversedMat = MatrixInitialization(2, 2);
        Inverse(PredictedObsercationCov, InversedMat);
        Multiply(mid_temp_mat, InversedMat, KalmanGain);

        // ----计算最终状态矩阵----
        Matrix* Observation = MatrixInitialization(1, 2);
        Observation -> Array[0][0] = SrcCoord.X;
        Observation -> Array[0][1] = SrcCoord.Y;
        FreeMatrix(mid_temp_mat);
        mid_temp_mat = MatrixInitialization(1, 2);
        Subtraction(Observation, PredictedObservationMean, mid_temp_mat);
        FreeMatrix(TransposedMat);
        TransposedMat = MatrixInitialization(2, 1);
        Transpose(mid_temp_mat, TransposedMat);
        Matrix* mid_temp_mat2 = MatrixInitialization(4, 1);
        Multiply(KalmanGain, TransposedMat, mid_temp_mat2);
        FreeMatrix(TransposedMat);
        TransposedMat = MatrixInitialization(1, 4);
        Transpose(mid_temp_mat2, TransposedMat);
        Addition(PredictedStateMean, TransposedMat, CurrentStateMean);

        // ----计算最终协方差矩阵----
        FreeMatrix(mid_temp_mat);
        mid_temp_mat = MatrixInitialization(2, 4);
        Multiply(H, PredictedStateCov, mid_temp_mat);
        FreeMatrix(mid_temp_mat2);
        mid_temp_mat2 = MatrixInitialization(4, 4);
        Multiply(KalmanGain, mid_temp_mat, mid_temp_mat2);
        Subtraction(PredictedStateCov, mid_temp_mat2, CurrentStateCov);


        CorrectedCoord.X = CurrentStateMean -> Array[0][0];
        CorrectedCoord.Y = CurrentStateMean -> Array[0][1];

        // ----释放内存----
        Kalman_free(PredictedStateMean, PredictedStateCov, mid_temp_mat, mid_temp_mat2, 
        TransposedMat, PredictedObservationMean, PredictedObsercationCov, 
        Observation, InversedMat, KalmanGain);

        // ----返回预测坐标结构体----
        return CorrectedCoord;
    }
}



static unsigned int crc32(const unsigned char *buf, unsigned int len)
{
    unsigned int i, crc = 0xFFFFFFFF;
    for (i = 0; i < len; i++)
    {
        crc = crc32table[(crc ^ buf[i]) & 0xff] ^ (crc >> 8); /* 8: right move 8 bit */
    }
    return crc ^ 0xFFFFFFFF;
}
/* Log level look up table */
static const char *hisignallingLevelNames[] = {
    "TRACE",
    "DEBUG",
    "INFO",
    "WARN",
    "ERROR",
    "FATAL"};
/* get hisignaling log level */
const char *HisignallingLevelNum(HisignallingLogType hisignallingLevel)
{
    if (hisignallingLevel >= HISIGNALLING_LEVEL_MAX)
    {
        return "NULL";
    }
    else
    {
        return hisignallingLevelNames[hisignallingLevel];
    }
}
#define RIGHT_MOVE_8_BIT (8)
#define RIGHT_MOVE_16_BIT (16)
#define RIGHT_MOVE_24_BIT (24)
/* hisignal Hi3861 message package */

static hi_u32 HisignallingDataPackage(HisignallingProtocalType *buf, hi_u32 len, hi_u8 *hisignallingDataBuf)
{
    hi_u32 crcCheckSend = 0;
    hi_u32 packageLen = 0;
    memcpy_s(hisignallingDataBuf, HISGNALLING_MSG_FRAME_HEADER_LEN,
             buf->frameHeader, HISGNALLING_MSG_FRAME_HEADER_LEN);
    memcpy_s(&hisignallingDataBuf[HISGNALLING_MSG_FRAME_HEADER_LEN],
             len, buf->hisignallingMsgBuf, len);
    memcpy_s(&hisignallingDataBuf[HISGNALLING_MSG_FRAME_HEADER_LEN + len],
             HISIGNALLING_MSG_HEADER_LEN, &(buf->endOfFrame), HISIGNALLING_MSG_HEADER_LEN);
    crcCheckSend = crc32(hisignallingDataBuf, (len + HISIGNALLING_MSG_HEADER_TAIL_LEN));
    hisignallingDataBuf[len + HISIGNALLING_MSG_HEADER_TAIL_LEN] =
        (hi_u8)((crcCheckSend & 0xff000000) >> RIGHT_MOVE_24_BIT);
    hisignallingDataBuf[len + HISIGNALLING_MSG_HEADER_TAIL_LEN + 1] = /* 1: addr offset */
        (hi_u8)((crcCheckSend & 0x00ff0000) >> RIGHT_MOVE_16_BIT);
    hisignallingDataBuf[len + HISIGNALLING_MSG_HEADER_TAIL_LEN + 2] = /* 2: addr offset */
        (hi_u8)((crcCheckSend & 0x0000ff00) >> RIGHT_MOVE_8_BIT);
    hisignallingDataBuf[len + HISIGNALLING_MSG_HEADER_TAIL_LEN + 3] = /* 3: addr offset */
        (hi_u8)crcCheckSend;
    packageLen = len + HISIGNALLING_MSG_HEADER_TAIL_LEN + HISGNALLING_MSG_CRC32_LEN;
    return packageLen;
}


void AlarmStart(uint32_t data)
{
    if (data == 1)
    {
         osThreadAttr_t attr;
#ifdef CONFIG_WIFI_AP_MODULE
    if (hi_wifi_start_softap() != 0) {
        printf("open softap failure\n");
        return;
    }
    printf("open softap ok\n");
#elif defined(CONFIG_WIFI_STA_MODULE)
    /* start wifi sta module */
    WifiStaModule();
#endif
    attr.name = "udp demo";
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = UDP_TASK_STACKSIZE;
    attr.priority = UDP_TASK_PRIOR;
    struct sockaddr_in serAddr = {0};
    struct sockaddr_in remoteAddr = {0};
    static int recvDataFlag = -1;
    char *sendData = NULL;
    int sServer = 0;

    printf(" This Pegasus udp server demo\r\n");
    sServer = UdpTransportInit(serAddr, remoteAddr);

    // 设置客户端地址信息
    remoteAddr.sin_family = AF_INET;
    remoteAddr.sin_port = htons(CLIENT_PORT);
    remoteAddr.sin_addr.s_addr = inet_addr(CLIENT_IP_ADDRESS);

    int addrLen = sizeof(remoteAddr);
    char recvData[UDP_RECV_LEN] = {0};
     sendData = "Received a message from the server";
     // 发送响应消息到客户端
            sendto(sServer, sendData, strlen(sendData), 0, (struct sockaddr*)&remoteAddr, addrLen);
    hi_sleep(FREE_CPU_TIME_20MS); 
     close(sServer);
        //IoTPwmStart(IOT_PWM_PORT_PWM3, viberate_mode_value, 4000); 
        //IoTPwmStart(IOT_PWM_PORT_PWM1, viberate_mode_value, 4000); 
        if(OVERTAKING_REPORT){
        
        printf("************\n");
        printf("Left Overtaking\n");
        printf("Left Overtaking\n");
        printf("Left Overtaking\n");
        printf("Left Overtaking\n");
        printf("Left Overtaking\n");
        printf("************\n");
        }
        OledShowString(0, 0, "Overtaking:Left   ", 1);
        TaskMsleep(500);
       // IoTPwmStop(IOT_PWM_PORT_PWM3);
       // IoTPwmStop(IOT_PWM_PORT_PWM1);
    }
    else if (data == 2)
    {
          osThreadAttr_t attr;
#ifdef CONFIG_WIFI_AP_MODULE
    if (hi_wifi_start_softap() != 0) {
        printf("open softap failure\n");
        return;
    }
    printf("open softap ok\n");
#elif defined(CONFIG_WIFI_STA_MODULE)
    /* start wifi sta module */
    WifiStaModule();
#endif
    attr.name = "udp demo";
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = UDP_TASK_STACKSIZE;
    attr.priority = UDP_TASK_PRIOR;
    struct sockaddr_in serAddr = {0};
    struct sockaddr_in remoteAddr = {0};
    static int recvDataFlag = -1;
    char *sendData = NULL;
    int sServer = 0;

    printf(" This Pegasus udp server demo\r\n");
    sServer = UdpTransportInit(serAddr, remoteAddr);

    // 设置客户端地址信息
    remoteAddr.sin_family = AF_INET;
    remoteAddr.sin_port = htons(CLIENT_PORT);
    remoteAddr.sin_addr.s_addr = inet_addr(CLIENT_IP_ADDRESS);

    int addrLen = sizeof(remoteAddr);
    char recvData[UDP_RECV_LEN] = {0};
     sendData = "Received a message from the server";
     // 发送响应消息到客户端
            sendto(sServer, sendData, strlen(sendData), 0, (struct sockaddr*)&remoteAddr, addrLen);
    hi_sleep(FREE_CPU_TIME_20MS); 
     close(sServer);
        // #if OVERTAKING_PRINT
      //  IoTPwmStart(IOT_PWM_PORT_PWM0, viberate_mode_value, 4000); // 50
      //  IoTPwmStart(IOT_PWM_PORT_PWM1, viberate_mode_value, 4000);
        if(OVERTAKING_REPORT){
        printf("************\n");
        printf("Right Overtaking\n");
        printf("Right Overtaking\n");
        printf("Right Overtaking\n");
        printf("Right Overtaking\n");
        printf("Right Overtaking\n");
        printf("************\n");
        }
        OledShowString(0, 0, "Overtaking:Right   ", 1);
        // #endif
        TaskMsleep(500);
      //  IoTPwmStop(IOT_PWM_PORT_PWM0);
      //  IoTPwmStop(IOT_PWM_PORT_PWM1);
    }
}

void data_receive(uint32_t *orination)
{
    // FIFO
    for (uint32_t i = 12; i >= 4; i -= 4)
    {
        for (uint32_t j = 1; j <= 4; j++)
        {
            ori_buffer[i + 4 - j] = ori_buffer[i - j];
        }
    }
    for (uint32_t i = 0; i < 4; i++)
    {
        ori_buffer[i] = orination[i];
    }
    // #if DATA_ENTER_BUFFER_PRINT 1
    OledShowString(0, 0, "Tracking:ON       ", 1);
    if(DATA_REPORT)
    {
    printf("________________________________________________________________\n");
    printf("[DEBUG TIME %d] ", debug_count);
    for (uint32_t i = 0; i < 4; i++)
    {   
        printf("number%d = %d\t", i, ori_buffer[i]);
    }
    printf("|\n");
    printf("[DEBUG TIME %d] ", debug_count);
    for (uint32_t i = 4; i < 8; i++)
    {   
        printf("number%d = %d\t", i, ori_buffer[i]);
    }
    printf("|\n");
    printf("[DEBUG TIME %d] ", debug_count);
    for (uint32_t i = 8; i < 12; i++)
    {   
        printf("number%d = %d\t", i, ori_buffer[i]);
    }
    printf("|\n");
    printf("[DEBUG TIME %d] ", debug_count);
    for (uint32_t i = 12; i < 16; i++)
    {   
        printf("number%d = %d\t", i, ori_buffer[i]);
    }
    printf("|\n");
    printf("________________________________________________________________\n");
    }
}

uint32_t s_cal(uint32_t *orination) // 计算最新一帧图像面积
{
    return (orination[2] - orination[0]) * (orination[3] - orination[1]);
}

void base_data_settle(uint32_t *orination)
{
    uint32_t x_min = orination[0];
    uint32_t y_min = orination[1];
    uint32_t x_max = orination[2];
    uint32_t y_max = orination[3];
    uint32_t scale = s_cal(orination);
    if (scale > APPROACH_OUT_GATE)
    {
        if ((x_min + x_max) >= 0 && (x_min + x_max) <= 1920 * 2)
        {
            if ((y_min + y_max) >= 0 && (y_min + y_max) <= 1080 * 2)
            {
                baseline_settle_flag = 1;
            }
        }
    }
    if (baseline_settle_flag)
    {
        for (int i = 0; i < 4; i++)
        {
            ori_buffer[i] = orination[i];
            base_data[i] = orination[i];
            printf("BASELINEDATA %d\n", base_data[i]);
            OledShowString(0, 0, "Target found       ", 1);
        }
    }
}

// 趋势方向和中心所在区域判断,返回一个趋势方向
uint32_t dirction_judge(uint32_t *orination)
{
    // 通过比较四个数据的x坐标差值给出一个方向判定；
    int dir_sum = 0;
    int x1, x2, x3, x4, x_ave;
    int x_dif_sum;
    x1 = ori_buffer[0];
    x2 = ori_buffer[4];
    x3 = ori_buffer[8];
    x4 = ori_buffer[12];
    x_dif_sum = -(x2 - x1 + x4 - x3) / 4;
    //printf("x_dif_sum = %d\n", x_dif_sum);
    if (x_dif_sum < LEFT_SHIFT)
    {
        toward_dir = LEFT;
    }
    else if (x_dif_sum > RIGHT_SHIFT)
    {
        toward_dir = RIGHT;
    }
    else
    {
        toward_dir = STILL;
    }

    x_ave = (ori_buffer[0] + ori_buffer[2] + ori_buffer[4] + ori_buffer[6]) / 4;
    //printf("ave = %d", x_ave);
    if (x_ave < 960)
    {
        center_dir_record = LEFT;
    }
    else
    {
        center_dir_record = RIGHT;
    }
    return toward_dir;
}

void Base_data_reset() // NOTTT
{
    for (int i = 0; i < 16; i++)
    {
        ori_buffer[i] = 0;
    }
    printf("\n[BASE DATA RESET]\n");
    OledShowString(0, 0, "Buffer reset   ", 1);
    baseline_settle_flag = 0;
    debug_count = 0;
    non_trag_count = 0;
    Record_state = 0;
}

void data_pre_process(uint32_t *orination)
{
    uint32_t dir = dirction_judge(orination);
    uint32_t offset = 0;
    int buffer_diff = ori_buffer[0] - ori_buffer[1] + ori_buffer[5] - ori_buffer[4];
    if (dir == LEFT)
    {
        offset = -5;
    }
    if (dir == RIGHT)
    {
        offset = 5;
    }
    printf("\e[1;1H\e[2J");
    printf("###########################################################################\n");
    printf("[DEBUG TIME %d]\n", debug_count);
    printf("[DEBUG TIME %d] ", debug_count);
    printf("Data_Before_judge x1=%d\ty1=%d\tx2=%d\ty2=%d\n", orination[0], orination[1], orination[2], orination[3]);
    printf("[DEBUG TIME %d] ", debug_count);
    printf("Base_Before_judge x1=%d\ty1=%d\tx2=%d\ty2=%d\n", base_data[0], base_data[1], base_data[2], base_data[3]);
    
    if ((orination[0] + orination[2] > INTERFACE_VALUE + base_data[0] + base_data[2])||
        (orination[0] + orination[2] < -INTERFACE_VALUE + base_data[0] + base_data[2])
    )// 如果大于扰动数据，则忽略该数据
    {
        printf("[OMIT DATA]\n");
        non_trag_count += 1; // Count the zero pin
        orination[0] = base_data[0] + offset;
        orination[1] = base_data[1];
        orination[2] = base_data[2];
        orination[3] = base_data[3];
    }else{
        printf("[ACCEPT DATA]\n");
    }

    // Coordinate raw_data = {orination[0], orination[1]};
    // Coordinate receiver = Kalman_smooth(raw_data);
    // orination[0] = (int) receiver.X;
    // orination[1] = (int) receiver.Y;

    // 把数据交给buffer

    data_receive(orination);

    // 重设basedata
    for (uint32_t i = 0; i < 4; i++)
    {
        base_data[i] = orination[i];
    }

    //printf("[FINISH pre_rpocess!]\n");
    debug_count += 1;
    // printf("Scale = %d\n", (orination[2]-orination[0])*(orination[3]-orination[1]));
    if(DIRECTION_REPORT){
    printf("[DEBUG TIME %d] ", debug_count);
    printf("xmin=%d xmax=%d\n", orination[0], orination[2]);
    printf("[DEBUG TIME %d] ", debug_count);
    printf("toward_dir= %d \n", toward_dir);
    printf("[DEBUG TIME %d] ", debug_count);
    printf("center dir = %d\n", center_dir_record);
    printf("###########################################################################");
    }

    if (non_trag_count > ZERO_TAR_GATE)
    {
        Base_data_reset();
    }
}

uint32_t over_detect(int server, struct sockaddr* Addr, socklen_t* length, char * senddata, char * recvdata)
{
    uint32_t scale = s_cal(ori_buffer);
    uint32_t x_min = ori_buffer[0];
    uint32_t x_max = ori_buffer[2];
    uint32_t x_mid = (x_max + x_min) / 2;
    uint32_t flag1 = 0;
    uint32_t flag2 = 0;
    uint32_t flag3 = 0;
    if (scale > SCALEGATE)
    {
        flag1 = 1;
        Record_state = 1;
    }
    if (flag1)
    {
        if (toward_dir == center_dir_record)
        {
            flag2 = 1;
        }
    }
    if (flag2)
    {
        if (center_dir_record == RIGHT)
        {
            if (x_max > CLOSEWINDOWGATE_RIGHT)
                flag3 = 1;
        }
        if (center_dir_record == LEFT)
        {
            if (x_min < CLOSEWINDOWGATE_LEFT)
                flag3 = 1;
        }
    }

    if (flag3)
    {
        if (toward_dir == RIGHT)
        {   
            // AlarmStart(LEFT);
            senddata = "right__________";
            sendto(server, senddata, strlen(senddata), 0, (struct sockaddr*)Addr, *length);
            recvfrom(server, recvdata, UDP_RECV_LEN, 0, (struct sockaddr*)Addr, (socklen_t*)length);
            printf("received:%s\n",recvdata);
        }
        if (toward_dir == LEFT)
        {
            senddata = "left___________";
            sendto(server, senddata, strlen(senddata), 0, (struct sockaddr*)Addr, *length);
            recvfrom(server, recvdata, UDP_RECV_LEN, 0, (struct sockaddr*)Addr, (socklen_t*)length);
            printf("received:%s\n",recvdata);
            // AlarmStart(RIGHT);
        }
    }
    else{
        senddata = "no_____________";
        sendto(server, senddata, strlen(senddata), 0, (struct sockaddr*)Addr, *length);
        recvfrom(server, recvdata, UDP_RECV_LEN, 0, (struct sockaddr*)Addr, (socklen_t*)length);
        printf("received:%s\n",recvdata);
        return NONE_OVER;
    }
}

uint32_t Entry_detect(uint32_t *orination, int server, struct sockaddr* Addr, socklen_t* length, char * senddata, char * recvdata)
{
    uint32_t over_rec = 0;
    if (!baseline_settle_flag)
    {
        base_data_settle(orination); // 设定base数据
    }
    if (baseline_settle_flag) // 如果base数据已设定，则进入数据处理阶段
    {
        data_pre_process(orination);
        over_rec = over_detect(server,(struct sockaddr*) Addr, (socklen_t*)length, senddata,recvdata);
        return over_rec;
    }
}


/* hisignal Hi3861 message recevice */
HisignallingErrorType HisignallingMsgReceive(hi_u8 *buf, hi_u32 len, int server, struct sockaddr* Addr, socklen_t* length,char * senddata, char * recvdata)
{
    uint32_t x1 = (buf[3] << 8) + buf[4];
    uint32_t y1 = (buf[5] << 8) + buf[6];
    uint32_t x2 = (buf[7] << 8) + buf[8];
    uint32_t y2 = (buf[9] << 8) + buf[10];
    uint32_t Loc[4] = {x1, y1, x2, y2};
    uint32_t OVER = 0;
    // 执行行为判断
    Entry_detect(Loc, server,(struct sockaddr*) Addr, (socklen_t*)length,senddata,recvdata);
    return HISIGNALLING_RET_VAL_CORRECT;
}

/* hisignal Hi3861 message send */
hi_u32 HisignallingMsgSend(char *buf, hi_u32 dataLen)
{
    HisignallingProtocalType hisignallingMsg = {0};
    hi_u8 hisignallingSendBuf[HISIGNALLING_MSG_BUFF_LEN] = {0};
    hi_u32 hisignallingPackageLen = 0;
    hi_u32 writeDataLen = 0;

    hisignallingMsg.frameHeader[0] = HISIGNALLING_MSG_FRAME_HEADER_1;
    hisignallingMsg.frameHeader[1] = HISIGNALLING_MSG_FRAME_HEADER_2;
    (void)memcpy_s(hisignallingMsg.hisignallingMsgBuf, dataLen, buf, dataLen);
    hisignallingMsg.endOfFrame = HISIGNALLING_MSG_FRAME_TAIL;

    hisignallingPackageLen = HisignallingDataPackage(&hisignallingMsg, dataLen, hisignallingSendBuf);
    if (!hisignallingPackageLen)
    {
        HISIGNALLING_LOG_ERROR("hisignaling_data_package failed\r\n");
        return HI_ERR_FAILURE;
    }
    if (*hisignallingSendBuf == NULL)
    {
        HISIGNALLING_LOG_ERROR("hisignal send buf is null!\r\n");
        return HI_ERR_FAILURE;
    }
    writeDataLen = IoTUartWrite(HI_UART_IDX_1, hisignallingSendBuf, hisignallingPackageLen);
    if (!writeDataLen)
    {
        HISIGNALLING_LOG_ERROR("hi_uart_write failed\r\n");
        return HI_ERR_FAILURE;
    }
    return HI_ERR_SUCCESS;
}

int SetUartReceiveFlag(void)
{
    return recConfig.g_uartReceiveFlag;
}

hi_void *HisignallingMsgHandle(char *param)
{
    unsigned char *recBuff = NULL;

    struct sockaddr_in serAddr = {0};
    struct sockaddr_in remoteAddr = {0};
    static int recvDataFlag = -1;
    char *sendData = NULL;
    int sServer = 0;

    (char*)(param);
    printf(" This Pegasus udp server demo\r\n");
    sServer = UdpTransportInit(serAddr, remoteAddr);

    int addrLen = sizeof(remoteAddr);
    char recvData[UDP_RECV_LEN] = {0};

    int recvLen = recvfrom(sServer, recvData, UDP_RECV_LEN, 0, (struct sockaddr*)&remoteAddr, (socklen_t*)&addrLen);
    printf("received:%s\n",recvData);
    while(strstr(recvData, "let_us_talk____") == NULL){
        sendData = "ready__________";
        sendto(sServer, sendData, strlen(sendData), 0, (struct sockaddr*)&remoteAddr, addrLen);
        recvLen = recvfrom(sServer, recvData, UDP_RECV_LEN, 0, (struct sockaddr*)&remoteAddr, (socklen_t*)&addrLen);
        printf("received:%s\n",recvData);
    }
    printf("ready to talk\n");
     while(strstr(recvData, "let_us_talk____") == NULL){
        sendData = "ready__________";
        sendto(sServer, sendData, strlen(sendData), 0, (struct sockaddr*)&remoteAddr, addrLen);
        recvLen = recvfrom(sServer, recvData, UDP_RECV_LEN, 0, (struct sockaddr*)&remoteAddr, (socklen_t*)&addrLen);
        printf("received:%s\n",recvData);
    }
    printf("ready to talk\n");
    while (1)
    {
        (void)memset_s(g_sendUartBuff, sizeof(g_sendUartBuff) / sizeof(g_sendUartBuff[0]),
                       0x0, sizeof(g_sendUartBuff) / sizeof(g_sendUartBuff[0]));
        if (GetUartConfig(UART_RECEIVE_FLAG) == HI_TRUE)
        {
            /* 接收数据 */
            HisignallingMsgReceive(GetUartReceiveMsg(), GetUartConfig(UART_RECVIVE_LEN), sServer,(struct sockaddr*) &remoteAddr, (socklen_t*)&addrLen,sendData, recvData);
            /* 回显数据组包 */
            if (GetUartConfig(UART_RECVIVE_LEN) > (HISGNALLING_MSG_CRC32_LEN + HISIGNALLING_MSG_HEADER_TAIL_LEN))
            {
                recBuff = GetUartReceiveMsg();
                (void)memcpy_s(g_sendUartBuff,
                                (GetUartConfig(UART_RECVIVE_LEN) - HISGNALLING_MSG_CRC32_LEN - HISIGNALLING_MSG_HEADER_TAIL_LEN),
                                &recBuff[HISGNALLING_MSG_FRAME_HEADER_LEN],
                                (GetUartConfig(UART_RECVIVE_LEN) - HISGNALLING_MSG_CRC32_LEN - HISIGNALLING_MSG_HEADER_TAIL_LEN));
                /* 接收到Hi3516DV300数据后，发送回显 */
                // g_sendUartBuff[0] = Record_state;
                HisignallingMsgSend(g_sendUartBuff,
                                    (GetUartConfig(UART_RECVIVE_LEN) - HISGNALLING_MSG_CRC32_LEN - HISIGNALLING_MSG_HEADER_TAIL_LEN));
            }
            // g_sendUartBuff[0] = Record_state;
            // HisignallingMsgSend(g_sendUartBuff,
            //                         (GetUartConfig(UART_RECVIVE_LEN) - HISGNALLING_MSG_CRC32_LEN - HISIGNALLING_MSG_HEADER_TAIL_LEN));
            (void)SetUartRecvFlag(UART_RECV_FALSE);
            ResetUartReceiveMsg();
        }
        TaskMsleep(HISGNALLING_FREE_TASK_TIME);
    }
}

hi_u32 HisignalingMsgTask(hi_void) // NOTTT
{
    hi_u32 ret = 0;
    KeyMatrixInitialization();
    IoTGpioInit(LED_TEST_GPIO);
    IoTGpioSetDir(LED_TEST_GPIO, IOT_GPIO_DIR_OUT);
    IoTGpioInit(IOT_PWM_BEEP_left);  // 6
    IoSetFunc(IOT_PWM_BEEP_left, 5); /* 设置IO5功能 */
    IoTGpioSetDir(IOT_PWM_BEEP_left, IOT_GPIO_DIR_OUT);
    IoTPwmInit(IOT_PWM_PORT_PWM3); // 3

    IoTGpioInit(IOT_PWM_BEEP_right);  // 7
    IoSetFunc(IOT_PWM_BEEP_right, 5); /* 设置IO5功能 */
    IoTGpioSetDir(IOT_PWM_BEEP_right, IOT_GPIO_DIR_OUT);
    IoTPwmInit(IOT_PWM_PORT_PWM0); // 0

    IoTGpioInit(IOT_PWM_BUZZER);  // 10
    IoSetFunc(IOT_PWM_BUZZER, 5); /* 设置IO5功能 */
    IoTGpioSetDir(IOT_PWM_BUZZER, IOT_GPIO_DIR_OUT);
    IoTPwmInit(IOT_PWM_PORT_PWM1); // 1

    OledInit();
    OledFillScreen(0);
    IoTI2cInit(AHT20_I2C_IDX, AHT20_BAUDRATE);

    WifiStaModule();
    osThreadAttr_t hisignallingAttr = {0};

    // osTimerId_t periodic_tid = osTimerNew(cb_timeout_periodic, osTimerPeriodic, NULL, NULL);
    // osStatus_t status = osTimerStart(periodic_tid, 10);

    hisignallingAttr.stack_size = HISIGNALLING_MSG_TASK_STACK_SIZE;
    hisignallingAttr.priority = HISIGNALLING_MSG_TASK_PRIO;
    hisignallingAttr.name = (hi_char *)"hisignal msg task";

    if (osThreadNew((osThreadFunc_t)HisignallingMsgHandle, NULL, &hisignallingAttr) == NULL)
    {
        HISIGNALLING_LOG_ERROR("Failed to create hisignaling msg task\r\n");
        return HI_ERR_FAILURE;
    }
    return HI_ERR_SUCCESS;
}

SYS_RUN(HisignalingMsgTask);
